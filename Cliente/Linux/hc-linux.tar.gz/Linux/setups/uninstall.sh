#!/bin/sh
rm -rf /etc/init.d/hardware-collector-daemon
rm -rf /usr/share/hardware-collector-linux
rm -r /var/run/hcl.pid

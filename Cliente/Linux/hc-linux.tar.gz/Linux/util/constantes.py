MAQUINA_REGISTRADA = "maquina_registrada"
CONFIGURAR = "configurar"
SOLICITAR = "solicitar"
INFORMAR = "informar"

#Componentes
PROCESADOR = "procesador"
MEMORIAS_RAM = "memorias_ram"
DISCOS_DUROS = "discos_duros"

#Proceso
PIDAPP="/var/hcl.pid"

#End of Message
EOM="\r\n"
